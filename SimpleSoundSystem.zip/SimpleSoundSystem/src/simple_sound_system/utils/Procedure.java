package simple_sound_system.utils;

public interface Procedure {
	void Invoke() throws Exception;
}
